<?php
// Heading
$_['heading_title'] = 'All Reviews';

// Text
$_['text_tax']      = 'Ex Tax:';
